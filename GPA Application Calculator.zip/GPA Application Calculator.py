from tkinter import *

top = Tk()
top.title("GPA Calculator")
top.minsize(400,400)

subject1 = Label(text="Subject 1")
subject1.pack()
subject1_entry = Entry()
subject1_entry.pack()

subject2 = Label(text="Subject 2")
subject2.pack()
subject2_entry = Entry()
subject2_entry.pack()

subject3 = Label(text="Subject 3")
subject3.pack()
subject3_entry = Entry()
subject3_entry.pack()

subject4 = Label(text="Subject 4")
subject4.pack()
subject4_entry = Entry()
subject4_entry.pack()

subject5 = Label(text="Subject 5")
subject5.pack()
subject5_entry = Entry()
subject5_entry.pack()

subject6 = Label(text="Subject 6")
subject6.pack()
subject6_entry = Entry()
subject6_entry.pack()
def get_average():
    subject1_mark = int(subject1_entry.get())
    subject2_mark = int(subject2_entry.get())
    subject3_mark = int(subject3_entry.get())
    subject4_mark = int(subject4_entry.get())
    subject5_mark = int(subject5_entry.get())
    subject6_mark = int(subject6_entry.get())

    average = (subject1_mark + subject2_mark + subject3_mark + subject4_mark + subject5_mark + subject6_mark) / 6
    if (average >= 90):
        Grade = "A"
    elif (90 > average >= 80 ):
        Grade = "B"
    elif (80 > average >= 70):
        Grade = "C"
    elif (70 > average >= 60):
        Grade = "D"
    else:
        Grade = "F"
    result = Label(text="Your GBA is " + Grade)
    result.pack()

button = Button(text="Calculate My GBA", command = get_average)
button.pack()



mainloop( )